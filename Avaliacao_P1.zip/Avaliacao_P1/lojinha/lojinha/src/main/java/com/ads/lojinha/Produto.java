package com.ads.lojinha;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Produto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    private int codigo;
    private String nome;
    private String descritivo;
    private String tipoDeMaterial; 
    private double valor;
    private double valorPromo;
    private int quantidade;
    private int destaque;

    public Produto() {}

    public Produto(int codigo, String nome, String descritivo, String tipoDeMaterial, double valor, int quantidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.descritivo = descritivo;
        this.tipoDeMaterial = tipoDeMaterial;
        this.valor = valor;
        this.quantidade = quantidade;
    }

    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) { this.codigo = codigo; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDescritivo() { return descritivo; }
    public void setDescritivo(String descritivo) { this.descritivo = descritivo; }

    public String getTipoDeMaterial() { return tipoDeMaterial; }
    public void setTipoDeMaterial(String tipoDeMaterial) { this.tipoDeMaterial = tipoDeMaterial; }

    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    public double getValorPromo() { return valorPromo; }
    public void setValorPromo(double valorPromo) { this.valorPromo = valorPromo; }

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

    public int getDestaque() { return destaque; }
    public void setDestaque(int destaque) { this.destaque = destaque; }
}