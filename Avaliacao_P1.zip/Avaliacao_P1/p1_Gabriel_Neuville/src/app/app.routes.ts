import { Routes } from '@angular/router';
import { Busca } from './busca/busca';
import { Cadastro } from './cadastro/cadastro';
import { Cesta } from './cesta/cesta';
import { Detalhe } from './detalhe/detalhe';
import { Login } from './login/login';
import { Vitrine } from './vitrine/vitrine';
import { EsqueciSenha } from './esqueci-senha/esqueci-senha';
import { HistoricoCompra } from './historico-compra/historico-compra';

export const routes: Routes = [
    { path: "busca", component: Busca }, 
    { path: "cadastro", component: Cadastro },
    { path: "cesta", component: Cesta }, 
    { path: "detalhe/:codigo", component: Detalhe },
    { path: "esqueci-senha", component: EsqueciSenha }, 
    { path: "login", component: Login },
    { path: "historico-compra", component: HistoricoCompra},
    { path: "vitrine", component: Vitrine }, 
    { path: "", component: Vitrine },
    { path: "**", redirectTo: "vitrine" }
];

