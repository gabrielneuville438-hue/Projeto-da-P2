import { Component, signal } from '@angular/core';
import { Router, RouterOutlet, RouterLink } from '@angular/router'; 
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Produtos } from './model/produtos';
import { ListaProduto } from './model/lista-produto';
import { Busca, FiltroPesquisa } from './busca/busca';
import { ProdutosService } from './services/produtos.service'; 
import { SessaoService } from './services/sessao.service';

@Component({
  imports: [RouterOutlet, RouterLink, CommonModule, FormsModule, Busca], 
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  protected readonly title = signal('p1_Gabriel_Neuville');

  constructor(
    private produtosService: ProdutosService,
    private router: Router,
    public sessaoService: SessaoService
) {}

  filtrarProdutos(filtro: FiltroPesquisa): void {
    this.produtosService.atualizarFiltro(filtro);
    //Se a pessoa pesquisar estando na cesta, no detalhe etc., volta para a vitrine para ver o resultado
    const naVitrine = this.router.url === '/' || this.router.url.startsWith('/vitrine');
    if (!naVitrine) {
      this.router.navigate(['/vitrine']);
    }
  }
}