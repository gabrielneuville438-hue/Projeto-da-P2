import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

export interface FiltroPesquisa {
  termo: string;
  materiais: string[];
}

export interface OpcaoMaterial {
  rotulo: string;
  palavras: string[];
}

// Cada opção do filtro reúne as palavras (em minúsculas e sem acento) que
// identificam o material no campo "tipoDeMaterial" dos produtos.
// Para criar uma nova opção, basta acrescentar uma linha nesta lista.
export const MATERIAIS: OpcaoMaterial[] = [
  { rotulo: 'Madeira', palavras: ['madeira'] },
  { rotulo: 'Mármore', palavras: ['marmore'] },
  { rotulo: 'Bronze', palavras: ['bronze'] },
  { rotulo: 'Ouro', palavras: ['ouro'] },
  { rotulo: 'Vidro / Cristal', palavras: ['vidro', 'cristal'] },
  { rotulo: 'Latão', palavras: ['latao'] },
  { rotulo: 'Metal / Alumínio', palavras: ['metal', 'aluminio'] },
  { rotulo: 'Tecido / Têxtil', palavras: ['tecido', 'textil', 'veludo', 'algodao'] },
  { rotulo: 'Pedra / Fóssil', palavras: ['pedra', 'rocha', 'fossil'] },
  { rotulo: 'Laca', palavras: ['laca'] },
  { rotulo: 'Terracota / Gesso', palavras: ['terracota', 'gesso'] },
  { rotulo: 'Gravura / Litografia', palavras: ['litografia'] }
];

@Component({
  imports: [FormsModule],
  selector: 'app-busca',
  styleUrl: './busca.css',
  templateUrl: './busca.html',
})
export class Busca {
  readonly materiais: OpcaoMaterial[] = MATERIAIS;
  termoPesquisa: string = '';
  materialSelecionado: string = '';
  @Output() aoPesquisar = new EventEmitter<FiltroPesquisa>();

  get temFiltro(): boolean {
    return this.termoPesquisa.trim() !== '' || this.materialSelecionado !== '';
  }

  executarPesquisa(): void {
    const opcao = this.materiais.find(m => m.rotulo === this.materialSelecionado);
    this.aoPesquisar.emit({
      termo: this.termoPesquisa.trim(),
      materiais: opcao ? opcao.palavras : []
    });
  }

  limparPesquisa(): void {
    this.termoPesquisa = '';
    this.materialSelecionado = '';
    this.executarPesquisa();
  }
}
