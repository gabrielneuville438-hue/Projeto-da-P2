import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { ClienteService } from '../services/cliente.service';

@Component({
  imports: [CommonModule, FormsModule, RouterLink],
  selector: 'app-cadastro',
  styleUrl: './cadastro.css',
  templateUrl: './cadastro.html',
})
export class Cadastro {
  usuario = {
    nome: '',
    email: '',
    senha: '',
    confirmarSenha: '',
    cpf: '',
    telefone: '',
    endereco: ''
  };
  exibirSucesso: boolean = false;
  erroSenhaDiferente: boolean = false;
  erroCadastro: boolean = false;

  constructor(
    private router: Router,
    private clienteService: ClienteService
  ) {}

  salvarCadastro(form: any): void {
    this.erroSenhaDiferente = false;
    this.erroCadastro = false;

    if(this.usuario.senha !== this.usuario.confirmarSenha) {
      this.erroSenhaDiferente = true;
      return;
    }

    if(form.valid) {
      //Mapeamento dos campos do formulário para formato esperado pelo ClienteService
      const novoCliente = {
        nome: this.usuario.nome,
        email: this.usuario.email,
        senha: this.usuario.senha,
        documento: this.usuario.cpf,
        telefone: this.usuario.telefone,
        endereco: this.usuario.endereco
      };
      
      this.clienteService.cadastrar(novoCliente).subscribe({
        next: () => {
          this.exibirSucesso = true;
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        },
        error: (erro: any) => {
          console.error('Erro ao cadastrar cliente:', erro);
          this.erroCadastro = true;
        }
      });
      
    }
  }
}
