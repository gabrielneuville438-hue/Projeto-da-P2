import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { ListaCesta } from "../model/lista-cesta";
import { Produtos } from "../model/produtos";
import { SessaoService } from "../services/sessao.service";
import { PedidoRegistro, PedidoService } from "../services/pedido.service";

@Injectable({
    providedIn: 'root'
})
export class CestaService {
    private itens: ListaCesta[] = [];

    constructor(
        private sessaoService: SessaoService,
        private pedidoService: PedidoService,
        private router: Router
    ) {
        const itensSalvos = localStorage.getItem('cesta_antiguidades');
        if (itensSalvos) {
            this.itens = JSON.parse(itensSalvos);
        }
    }

    private salvarNoStorage(): void {
        localStorage.setItem('cesta_antiguidades', JSON.stringify(this.itens));
    }

    getItens(): ListaCesta[] {
        return this.itens;
    }

    adicionar(produto: Produtos): void {
        const itemExistente = this.itens.find(item => item.codigo === produto.codigo);
        if (itemExistente) {
            itemExistente.quantidade++;
        } else {
            this.itens.push({
                codigo: produto.codigo,
                nome: produto.nome,
                preco: produto.valor,
                quantidade: 1
            });
        }
        this.salvarNoStorage();
    }

    incrementar(codigo: number): void {
        const item = this.itens.find(i => i.codigo === codigo);
        if (item) {
            item.quantidade++;
            this.salvarNoStorage();
        }
    }

    decrementar(codigo: number): void {
        const item = this.itens.find(i => i.codigo === codigo);
        if (item) {
            if (item.quantidade > 1) {
                item.quantidade--;
                this.salvarNoStorage();
            } else {
                this.removerItem(codigo);
            }
        }
    }

    removerItem(codigo: number): void {
        this.itens = this.itens.filter(i => i.codigo !== codigo);
        this.salvarNoStorage();
    }

    calcularTotal(): number {
        return this.itens.reduce((total, item) => total + (item.preco * item.quantidade), 0);
    }

    limparCesta(): void {
        this.itens = [];
        localStorage.removeItem('cesta_antiguidades');
    }

    finalizarCompra(): void {
        if (this.itens.length === 0) {
            alert("Sua cesta está vazia!");
            return;
        }
        
        if (!this.sessaoService.logado()) {
            alert("Por favor, faça login para concluir sua compra.");
            this.router.navigate(['/login']);
            return;
        }

        const clienteLogado: any = this.sessaoService.cliente();
        const emailCliente = clienteLogado?.email || '';
        const codigoId = Number(clienteLogado?.codigo ?? clienteLogado?.codigoCliente ?? clienteLogado?.id ?? 0)
            || this.pedidoService.gerarCodigoPorEmail(emailCliente);

        const totalCompra = this.calcularTotal();
        const hojeIso = new Date().toISOString().split('T')[0];

        const novoPedido: PedidoRegistro = {
            dataPedido: hojeIso,
            valorTotal: totalCompra,
            entrega: clienteLogado?.endereco || 'Entrega Padrão',
            codigoCliente: codigoId,
            clienteEmail: emailCliente,
            itens: [...this.itens],
            status: 'Concluído'
        };

        this.pedidoService.cadastrar(novoPedido).subscribe({
            next: () => {
                alert(`Compra finalizada com sucesso! Total: R$ ${totalCompra.toFixed(2)}`);
                this.limparCesta();
                this.router.navigate(['/historico-compra']);
            }
        });
    }
}