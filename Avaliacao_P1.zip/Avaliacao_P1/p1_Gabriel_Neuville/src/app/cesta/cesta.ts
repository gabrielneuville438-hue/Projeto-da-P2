import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CestaService } from './cesta.service';
import { ListaCesta } from '../model/lista-cesta';

@Component({
  imports: [CommonModule, RouterLink],
  selector: 'app-cesta',
  styleUrl: './cesta.css',
  templateUrl: './cesta.html',
})
export class Cesta implements OnInit {
  get itensCesta(): ListaCesta[] {
    return this.cestaService.getItens();
  }

  constructor(public cestaService: CestaService) {}

  ngOnInit(): void {}
}

