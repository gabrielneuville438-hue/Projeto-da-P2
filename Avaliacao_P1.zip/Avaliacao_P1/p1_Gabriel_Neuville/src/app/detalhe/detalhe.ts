import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Produtos } from '../model/produtos';
import { ListaProduto } from '../model/lista-produto';
import { CestaService } from '../cesta/cesta.service';

@Component({
  imports: [CommonModule],
  selector: 'app-detalhe',
  styleUrl: './detalhe.css',
  templateUrl: './detalhe.html',
})

export class Detalhe implements OnInit {
  produto?: Produtos;
  
  constructor(
    private route: ActivatedRoute, 
    public cestaService: CestaService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const codigoUrl = Number(this.route.snapshot.paramMap.get('codigo'));
    this.produto = ListaProduto.find(p => p.codigo === codigoUrl);
  }

  comprar(): void {
    if (this.produto) {
      this.cestaService.adicionar(this.produto);
      this.router.navigate(['/cesta']);
    }
  }
}

