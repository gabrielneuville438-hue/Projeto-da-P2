import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HistoricoCompra } from './historico-compra';

describe('HistoricoCompra', () => {
  let component: HistoricoCompra;
  let fixture: ComponentFixture<HistoricoCompra>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HistoricoCompra],
    }).compileComponents();

    fixture = TestBed.createComponent(HistoricoCompra);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
