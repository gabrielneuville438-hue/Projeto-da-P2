import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { PedidoService, PedidoRegistro } from '../services/pedido.service';
import { SessaoService } from '../services/sessao.service';

@Component({
  selector: 'app-historico-compra',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './historico-compra.html',
  styleUrl: './historico-compra.css'
})
export class HistoricoCompra implements OnInit {
  pedidos = signal<PedidoRegistro[]>([]);

  constructor(
    private pedidoService: PedidoService,
    public sessaoService: SessaoService
  ) {}

  ngOnInit(): void {
    const cliente: any = this.sessaoService.cliente();
    const emailCliente = cliente?.email || '';
    const codigoCliente = Number(cliente?.codigo ?? cliente?.codigoCliente ?? cliente?.id ?? 0)
      || this.pedidoService.gerarCodigoPorEmail(emailCliente);

    this.pedidoService.listarPorCliente(codigoCliente, emailCliente).subscribe({
      next: (lista) => {
        this.pedidos.set(lista);
      }
    });
  }
}