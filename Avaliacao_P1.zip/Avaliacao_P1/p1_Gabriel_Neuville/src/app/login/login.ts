import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ClienteService } from '../services/cliente.service';
import { SessaoService } from '../services/sessao.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  email: string = '';
  senha: string = '';
  exibirErro: boolean = false;

  constructor(
    private router: Router,
    private clienteService: ClienteService,
    private sessaoService: SessaoService
  ) {}

  fazerLogin(): void {
    //Chama o backend para validar a autentificação
    this.clienteService.login({email: this.email, senha: this.senha}).subscribe({
      next: (cliente: any) => {
        if (cliente && (cliente.nome || cliente.email)) {
          this.exibirErro = false;
          this.sessaoService.entrar(cliente); 
          this.router.navigate(['/vitrine']); 
        } else {
          this.exibirErro = true;
        }
      },
      error: () => {
        this.exibirErro = true;
      }
    });
  }
}