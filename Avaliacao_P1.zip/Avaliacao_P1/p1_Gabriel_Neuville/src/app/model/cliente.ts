export interface Cliente {
  codigo?: number;
  nome: string;
  email: string;
  senha?: string;
  // adicione outros campos se necessário (telefone, cpf, etc.)
}