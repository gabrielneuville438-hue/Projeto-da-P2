import { ListaCesta } from './lista-cesta';

describe('ListaCesta', () => {
  it('should create an instance', () => {
    expect(new ListaCesta()).toBeTruthy();
  });
});
