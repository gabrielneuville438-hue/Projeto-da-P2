export class ListaCesta {
    codigo: number = 0;
    nome: string = "";
    preco: number = 0;
    quantidade: number = 0;
}
