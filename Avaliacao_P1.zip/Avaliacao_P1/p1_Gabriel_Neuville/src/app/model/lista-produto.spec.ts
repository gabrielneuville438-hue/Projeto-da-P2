import { ListaProduto } from './lista-produto';

describe('ListaProduto', () => {
  it('should create an instance', () => {
    expect(new ListaProduto()).toBeTruthy();
  });
});
