import { Produtos } from "./produtos";

export const ListaProduto: Produtos[] = [
    {
        codigo: 1,
        nome: "Buffet Estilo Luís XVI",
        descritivo: "Feito de Mognde Primeira Linha (Acajou) e mármore azul de Savoie dos alpes Franceses dos anos 1950-1960.",
        tipoDeMaterial: "Madeira e Mármore",
        valor: 14800.00,
        quantidade: 1
    },
    {
        codigo: 2,
        nome: "Biblioteca Vitrine Luís Filipe",
        descritivo: "Peça autêntica do período Luís Filipe (Século XIX) confeccionada em Mogno de alta qualidade e possui vidros das portas originais preservadas.",
        tipoDeMaterial: "Madeira e Vidro",
        valor: 22000.00,
        quantidade: 1
    },
    {
        codigo: 3,
        nome: "Escultura 'Combat de Panthères' - Georges Gardet",
        descritivo: "Uma escultura de mais de 50 quilos feita em 1900, tendo uma idêntica no Museu de Orsay, em Paris.",
        tipoDeMaterial: "Terracota / Gesso Patinado",
        valor: 45000.00,
        quantidade: 1
    },
    {
        codigo: 4,
        nome: "Espelho Provençal Estilo Luís XV",
        descritivo: "Espelho na dimensão 116X81 com molduras de madeiras douradas originais do Século XVIII, mas o espelho foi substituido do século XIX.",
        tipoDeMaterial: "Madre e Cristal",
        valor: 28000.00,
        quantidade: 1
    },
    {
        codigo: 5,
        nome: "Relógio de Mesa com Grifos",
        descritivo: "Vindo do período do Consulado (época refernte de Napoleão) feito de bronze dourado e a base de mármores brancos e pretos, mas o mecânismo original foi substituido por um não posterior (parte vísivle na parte posterior).",
        tipoDeMaterial: "Bronze Dourado e Mármore",
        valor: 16500.00,
        quantidade: 1
    },
    {
        codigo: 6,
        nome: "Sofá de Época Biedermeier",
        descritivo: "Exemplar clássico (Século XIX) do refinado mobiliário burguês da Europa Central, sendo folheado de mogno e decorado com madeira de sicômoro.",
        tipoDeMaterial: "Madeira e Tecido",
        valor: 19500.00,
        quantidade: 1
    },
    {
        codigo: 7,
        nome: "Lustre Art Déco de Muller Frères Lunéville",
        descritivo: "Lustre pendente com armação em bronze prateado e detalhes em latão, que apresenta tulipas de vidro acetinado com relevos de folhagens frondosas. Com peça assinada pelos mestres vidreiros renomados da França.",
        tipoDeMaterial: "Bronze Prateado, Latão e Vidro Acetinado.",
        valor: 18400.00,
        quantidade: 1
    },
    {
        codigo: 8,
        nome: "Fóssil de Amonite Gigante",
        descritivo: "Uma criatura marítim extinta há milhões de anos com 66cm de diametro, 22cm de espessura e um peso aproximado de 100 quilos.",
        tipoDeMaterial: "Fóssil Natural / Rocha Mineralizada",
        valor: 52000.00,
        quantidade: 1
    },
    {
        codigo: 9,
        nome: "Escultura de Leão Heráldico em Pedra Natural",
        descritivo: "Leão esculpido no final do século XIX com altura de 118cm e apresenta pátina do tempo com marcas naturais e líquens.",
        tipoDeMaterial: "Pedra Natural",
        valor: 48000.00,
        quantidade: 2
    },
    {
        codigo: 10,
        nome: "Par de Poltronas 'Mondo' - Karl-Erik Ekselius",
        descritivo: "Foram desenhados no modelo escandinavo 'Mondo' para a Joc Möbel em Vetlanda, Súecia, 1960.",
        tipoDeMaterial: "Alumínio e Tecido",
        valor: 24000.00,
        quantidade: 2
    },
    {
        codigo: 11,
        nome: "Santuário Doméstico Pooja Mandir Indiano",
        descritivo: "Raríssimo e monumental santuário de 1920 com madeira policromada de padrões florais e colunas de leões guardiões, evocando a estética dos templos e palácios Haveli.",
        tipoDeMaterial: "Madeira Policromada e Entalhada",
        valor: 68000.00,
        quantidade: 1
    },
    {
        codigo: 12,
        nome: "Abajur Italiano em Vidro de Murano e Ouro",
        descritivo: "Criado em 1960, apresenta a base em latão maciço e uma cúpula em vidro soprado artesanalmente à mão com ouro translúcido; com tomada adapta para 120V.",
        tipoDeMaterial: "Vidro de Murano, Latão e Ouro",
        valor: 13500.00,
        quantidade: 1
    },
    {
        codigo: 13,
        nome: "Sofá Art Déco Húngaro em Veludo Roxo",
        descritivo: "Criado em 1930, proveniente de Budapeste. A peça exibe o glamour da época com imponente luxuoso veludo roxo profundo com mistura de geometria industrial ocidental e refinamento clássico do leste europeu.",
        tipoDeMaterial: "Madeira Ebanizada, Veludo e Folha de Ouro",
        valor: 29000.00,
        quantidade: 1
    },
    {
        codigo: 14,
        nome: "Vaso Art Decó Japônes",
        descritivo: "Vidro opaco acetinado com padrão floral que foi quebrado e refeito pela técnica Kintsugi, onde as faturas são unidas por laca e pó de ouro.",
        tipoDeMaterial: "Vidro Acetinado, Ouro e Metal",
        valor: 11200.00,
        quantidade: 1
    },
    {
        codigo: 15,
        nome: "Portal de Haveli",
        descritivo: "Portal de uma das mansões da aristocracia indiana entre 1920-1930. Sendo umas das sobreviventes da época perdida",
        tipoDeMaterial: "Madeira Nobre e Metal Dourado",
        valor: 95000.00,
        quantidade: 1
    },
    {
        codigo: 16,
        nome: "Painel Monumental Entalhado em Teca e Teca-Teca",
        descritivo: "A centralização da flor de lótus (reprsenta a pureza espiritual) feito de madeira Teca Antiga que é imune a cupins e vigas antigas de casarões (Teca-Teca). Com 2,10m de altura e de largura, é a arte tailandesa viva.",
        tipoDeMaterial: "Madeira de Teca e Teca-Teca",
        valor: 58000.00,
        quantidade: 1
    },
    {
        codigo: 17,
        nome: "Abajur com Base de Caixa de Laca Birmanesa do Século XIX",
        descritivo: "A base foi uma caixa de oferendas com imagens divinas de palacios sobre fundo vermelho-terracota.",
        tipoDeMaterial: "Laca Birmanesa, Madeira e Tecido",
        valor: 12800.00,
        quantidade: 1
    },
    {
        codigo: 18,
        nome: "Biombo de Casamento Imperial Chinês em Laca e Ouro",
        descritivo: "Um biombo de 8 divisões de ambientes feitos no século XVIII para um casal jóvem com poemas ligadas ao confucionismo.",
        tipoDeMaterial: "Madeira Lacada e Folha de Ouro",
        valor: 185000.00,
        quantidade: 1
    },
    {
        codigo: 19,
        nome: "Casaco Cerimonial Antigo da Tribo Akha",
        descritivo: "Item raríssimo da arte têxtil do século XX feito de algodão tingido com índigo natural em padrões tradicionais.",
        tipoDeMaterial: "Algodão Têxtil, Índigo e Miçangas",
        valor: 14500.00,
        quantidade: 1
    },
    {
        codigo: 20,
        nome: "Gravura 'Dia para Noite' - Daniel Siegel",
        descritivo: "Obra de arte contemporânea inspirada nas litografias europeias do século XVII.",
        tipoDeMaterial: "Litografia Contemporânea",
        valor: 6200.00,
        quantidade: 1
    }
];
