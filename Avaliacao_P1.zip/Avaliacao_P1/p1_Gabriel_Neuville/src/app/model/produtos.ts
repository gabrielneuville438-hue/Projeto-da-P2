export class Produtos {
    codigo: number = 0;
    nome: string = "";
    descritivo: string = "";
    tipoDeMaterial: string = "";
    valor: number = 0;
    quantidade: number = 0;
}
