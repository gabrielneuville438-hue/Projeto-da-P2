import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, catchError, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  private apiUrl = 'http://localhost:8080/api/cliente';
  private readonly STORAGE_KEY = 'clientes_cadastrados_local';

  constructor(private http: HttpClient) {}

  private obterClientesLocais(): any[] {
    const dados = localStorage.getItem(this.STORAGE_KEY);
    return dados ? JSON.parse(dados) : [];
  }

  private salvarClienteLocal(cliente: any): void {
    const lista = this.obterClientesLocais();
    //Evitar duplicação de e-mail
    const filtrada = lista.filter(c => c.email !== cliente.email);
    filtrada.push(cliente);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filtrada));
  }
  
  //Buscar cliente por código
  buscarPorCodigo(codigo: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${codigo}`);
  }
  //Cadastrar cliente
  cadastrar(cliente: {
    nome: string;
    email: string;
    senha: string;
    documento: string;
    telefone?: string;
    endereco?: string;
  }): Observable<any> {
    this.salvarClienteLocal(cliente);
    return this.http.post<any>(this.apiUrl, cliente, { responseType: 'text' as 'json' }).pipe(
      catchError((erro) => {
        console.warn('API indisponível/recusou, cadastro mantido localmente:', erro);
        return of('Cadastrado localmente');
      })
    );
  }
  //Alterar cliente
  alterar(cliente: { codigo: number; nome: string; email: string; senha: string; documento: string}): Observable<any> {
    return this.http.put<any>(this.apiUrl, cliente, { responseType: 'text' as 'json'});
  }
  //Excluir cliente por código
  excluir(codigo: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${codigo}`, { responseType: 'text' as 'json'});
  }
  //Login do cliente
  login(credenciais: { email: string; senha: string}): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login`, credenciais).pipe(
      map((respostaApi) => {
        //Devolve o cliente com nome ou email
        if(respostaApi && (respostaApi.nome || respostaApi.email)) {
          return respostaApi;
        }
        //Devolve null
        return this.buscarLocalmente(credenciais);
      }),
      catchError(() => {
        //Se API deu erro de HTTP, procura no cadastro localmente
        return of(this.buscarLocalmente(credenciais));
      })
    );
  }

  private buscarLocalmente(credenciais: { email: string; senha: string}): any {
    const emailDigitado = (credenciais.email || '').trim().toLowerCase();
    return this.obterClientesLocais().find(
      c => (c.email || '').trim().toLowerCase() === emailDigitado && c.senha === credenciais.senha
    ) || null;
  }

  //resetar senha
  resetarSenha(email: string): Observable<any> {
    return this.http.patch<any>(`${this.apiUrl}/resetarSenha`, { email }, { responseType: 'text' as 'json'});
  }
  //Alterar senha
  alterarSenha(dados: { email: string; documento: string; senha: string}): Observable<any> {
    return this.http.patch<any>(`${this.apiUrl}/alterarSenha`, dados, { responseType: 'text' as 'json'});
  }
}