import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, catchError, map } from 'rxjs';
import { ListaCesta } from '../model/lista-cesta';

export interface PedidoRegistro {
  codigoPedido?: number;
  dataPedido: string;
  valorTotal: number;
  entrega?: string;
  obs?: string;
  codigoCliente: number;
  clienteEmail?: string;
  itens: ListaCesta[];
  status?: string;
}

@Injectable({
  providedIn: 'root'
})
export class PedidoService {
  private apiUrl = 'http://localhost:8080/api/pedido';
  private readonly STORAGE_KEY = 'historico_pedidos_antique';

  constructor(private http: HttpClient) {}

  gerarCodigoPorEmail(email?: string): number {
    const emailNorm = (email || '').trim().toLowerCase();
    if (!emailNorm) return 0;

    let hash = 0;
    for (let i = 0; i < emailNorm.length; i++) {
      hash = (hash * 31 + emailNorm.charCodeAt(i)) | 0;
    }
    return Math.abs(hash) || 1;
  }

  private obterTodosPedidosLocais(): PedidoRegistro[] {
    const dados = localStorage.getItem(this.STORAGE_KEY);
    return dados ? JSON.parse(dados) : [];
  }

  private obterPedidosLocaisDoCliente(codigoCliente: number, emailCliente?: string): PedidoRegistro[] {
    const todos = this.obterTodosPedidosLocais();
    const emailNorm = (emailCliente || '').trim().toLowerCase();

    return todos.filter((p) => {
      if (emailNorm && p.clienteEmail) {
        return p.clienteEmail.trim().toLowerCase() === emailNorm;
      }
      if (codigoCliente > 0 && p.codigoCliente > 0) {
        return p.codigoCliente === codigoCliente;
      }
      return false;
    });
  }

  private salvarPedidoLocal(pedido: PedidoRegistro): void {
    const lista = this.obterTodosPedidosLocais();
    if (!pedido.codigoPedido) {
      pedido.codigoPedido = lista.length > 0 ? Math.max(...lista.map(p => p.codigoPedido || 0)) + 1 : 1001;
    }
    lista.unshift(pedido);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(lista));
  }

  cadastrar(pedido: PedidoRegistro): Observable<any> {
    if (!pedido.codigoCliente || pedido.codigoCliente <= 0) {
      pedido.codigoCliente = this.gerarCodigoPorEmail(pedido.clienteEmail);
    }

    this.salvarPedidoLocal(pedido);

    const payloadBackend = {
      valorTotal: pedido.valorTotal,
      entrega: pedido.entrega || 'Entrega Padrão',
      obs: JSON.stringify(pedido.itens),
      dataPedido: pedido.dataPedido,
      codigoCliente: pedido.codigoCliente
    };

    return this.http.post<any>(this.apiUrl, payloadBackend, { responseType: 'text' as 'json' }).pipe(
      catchError((erro) => {
        console.warn('Erro ao salvar pedido no backend, mantido localmente:', erro);
        return of('Pedido registrado localmente');
      })
    );
  }

  listarPorCliente(codigoCliente: number, emailCliente?: string): Observable<PedidoRegistro[]> {
    const codigoEfetivo = codigoCliente > 0 ? codigoCliente : this.gerarCodigoPorEmail(emailCliente);

    if (codigoEfetivo <= 0) {
      return of([]);
    }

    return this.http.get<any[]>(`${this.apiUrl}/cliente/${codigoEfetivo}`).pipe(
      map((listaApi) => {
        if (Array.isArray(listaApi)) {
          return listaApi.map((p) => {
            let itensRecuperados: ListaCesta[] = [];
            try {
              if (p.obs && p.obs.startsWith('[')) {
                itensRecuperados = JSON.parse(p.obs);
              }
            } catch {
              itensRecuperados = [];
            }

            return {
              codigoPedido: p.codigoPedido,
              dataPedido: p.dataPedido,
              valorTotal: p.valorTotal,
              entrega: p.entrega,
              obs: p.obs,
              codigoCliente: p.codigoCliente,
              itens: itensRecuperados,
              status: 'Concluído'
            } as PedidoRegistro;
          });
        }
        return [];
      }),
      catchError(() => of(this.obterPedidosLocaisDoCliente(codigoEfetivo, emailCliente)))
    );
  }
}