import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Produtos } from '../model/produtos';
import { FiltroPesquisa } from '../busca/busca';
import { ListaProduto } from '../model/lista-produto';

//Tira os acentos e deixa tudo em minúsculas
function normalizar(texto: string): string {
  return (texto || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

@Injectable({
  providedIn: 'root'
})
export class ProdutosService {
  private apiUrl = 'http://localhost:8080/api/produto';
  private apiListarGeral = 'http://localhost:8080/api/produtos';

  //Armazena a lista de produtos vindas da API
  private produtosApi = signal<Produtos[]>([]);

  //Guarda o filtro atual enviado pela barra de busca
  private filtroAtual = signal<FiltroPesquisa>({ termo: '', materiais: [] });

  constructor(private httpClient: HttpClient) {
    this.carregarProdutosDaApi();
  }

  //Carrega todos os produtos da API ao iniciar
  carregarProdutosDaApi(): void {
    this.httpClient.get<Produtos[]>(this.apiListarGeral).subscribe({
      next: (dados) => {
        if(dados && dados.length > 0) {
          this.produtosApi.set(dados);
        } else {
          this.produtosApi.set(ListaProduto);
        }
      },
      error: (erro) => {
        console.warn('API indisponível, carregando dados locais do TS...', erro);
        console.error('Erro ao carregar produtos da API:', erro);
      }
    });
  }

  //Busca direto no backend usando o endpoint `/api/produto/busca/{termo}`
  buscarNaApiPorTermo(termo: string): void {
    const termoBusca = termo.trim();
    if(!termoBusca) {
      this.carregarProdutosDaApi();
      return;
    }

    this.httpClient.get<Produtos[]>(`${this.apiUrl}/busca/${termoBusca}`).subscribe({
      next: (dados) => {
        this.produtosApi.set(dados);
      },
      error: (erro) => {
        console.error('Erro ao buscar produtos na API:', erro);
      }
    });
  }
  
  //Sinal computado que reage e filtra automaticamente os produtos carregados na tela
  produtosFiltrados = computed(() => {
    const palavras = normalizar(this.filtroAtual().termo).split(/\s+/).filter(p => p);
    const materiais = this.filtroAtual().materiais;

    return this.produtosApi().filter(produto => {
      const nomeProduto = normalizar((produto as any).descricao || produto.nome);
      const materialProduto = normalizar(produto.tipoDeMaterial);
      const atendeNome = palavras.every(palavra => nomeProduto.includes(palavra));
      const atendeMaterial = materiais.length === 0 || materiais.some(m => materialProduto.includes(m));
      return atendeMaterial && atendeNome;
    });
  });

  atualizarFiltro(filtro: FiltroPesquisa): void {
    this.filtroAtual.set(filtro);
  }

  carregarVitrine(): Observable<Produtos[]> {
    return this.httpClient.get<Produtos[]>(`${this.apiUrl}/vitrine`);
  }

  inserirProduto(produto: any): Observable<any> {
    return this.httpClient.post<any>(this.apiUrl, produto, { responseType: 'text' as 'json'});
  }

  deletarProduto(codigo: number): Observable<any> {
    return this.httpClient.delete<any>(`${this.apiUrl}/${codigo}`, { responseType: 'text' as 'json'});
  }
}