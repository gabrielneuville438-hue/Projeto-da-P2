import { Injectable, computed, signal } from '@angular/core';
import { Cliente } from '../model/cliente'; 

const CHAVE = 'cliente_logado';

@Injectable({
  providedIn: 'root'
})
export class SessaoService {
  readonly cliente = signal<Cliente | null>(this.lerSalvo());
  readonly logado = computed(() => this.cliente() !== null);

  entrar(cliente: Cliente): void {
    // nunca guardar a senha no navegador
    const { senha, ...seguro } = cliente;
    this.cliente.set(seguro);
    try {
      sessionStorage.setItem(CHAVE, JSON.stringify(seguro));
    } catch { /* sem storage disponível */ }
  }

  sair(): void {
    this.cliente.set(null);
    try {
      sessionStorage.removeItem(CHAVE);
    } catch { /* ignora */ }
  }

  private lerSalvo(): Cliente | null {
    try {
      const texto = sessionStorage.getItem(CHAVE);
      return texto ? JSON.parse(texto) as Cliente : null;
    } catch {
      return null;
    }
  }
}