import { Component } from '@angular/core';
import { Produtos } from '../model/produtos';
import { CommonModule } from '@angular/common';
import { ListaProduto } from '../model/lista-produto';
import { CestaService } from '../cesta/cesta.service';
import { Router } from '@angular/router';
import { ProdutosService } from '../services/produtos.service';

@Component({
  imports: [CommonModule],
  selector: 'app-vitrine',
  styleUrl: './vitrine.css',
  templateUrl: './vitrine.html',
})
export class Vitrine {
  
  constructor(public cestaService: CestaService,
              private router: Router,
              private produtosService: ProdutosService
  ) {}

  get lista(): Produtos[] {
    return this.produtosService.produtosFiltrados();
  }

  comprarNaVitrine(produto: Produtos): void {
    this.cestaService.adicionar(produto);
    this.router.navigate(['/cesta']);
  }

  irParaDetalhe(codigo: number): void {
    this.router.navigate(['/detalhe', codigo]);
  }
}
